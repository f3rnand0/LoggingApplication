*************** ***************
In Delivery / What to submit section says there must be a Wink folder BUT in the last paragraph:

So the resulting structure of your delivery should be:

<your_name - Software Architect - Java>.zip
<your_name - Software Architect - Java>.zip \ README.txt
<your_name - Software Architect - Java>.zip \ Design.doc
<your_name - Software Architect - Java>.zip \Code\
<your_name - Software Architect - Java>.zip \SQL\
<your_name - Software Architect - Java>.zip \Deployment\

There is not a folder for videos demos. So I created a Video folder besides the folders above.

*************** ***************